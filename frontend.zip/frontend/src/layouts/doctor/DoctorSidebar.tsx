// src/layouts/doctor/DoctorSidebar.tsx
import React, { useEffect, useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import {
  LayoutDashboardIcon,
  CalendarDaysIcon,
  ClipboardListIcon,
  UsersIcon,
  ActivityIcon,
  HelpCircleIcon,
  LogOutIcon,
  StethoscopeIcon,
  PanelLeftIcon,
  SunIcon,
  MoonIcon,
  UserIcon,
  BellIcon,
} from "lucide-react";
import { clearAuth } from "../../components/ProtectedRoute";

interface DoctorSidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

type ThemeMode = "light" | "dark";
const THEME_KEY = "theme";

const getInitialTheme = (): ThemeMode => {
  if (typeof window === "undefined") return "dark";
  const saved = localStorage.getItem(THEME_KEY) as ThemeMode | null;
  if (saved === "light" || saved === "dark") return saved;
  const prefersDark =
    window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? true;
  return prefersDark ? "dark" : "light";
};

const applyTheme = (mode: ThemeMode) => {
  const root = document.documentElement;
  if (mode === "dark") root.classList.add("dark");
  else root.classList.remove("dark");
};

const navItemBase =
  "flex items-center rounded-xl py-1.5 text-sm transition-colors";
const activeStyles =
  "bg-slate-900/90 text-slate-50 shadow-sm border border-slate-700";
const inactiveStyles =
  "text-slate-300 hover:text-white hover:bg-slate-800/70 border border-transparent";

export const DoctorSidebar: React.FC<DoctorSidebarProps> = ({
  isOpen,
  onToggle,
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const userName = localStorage.getItem("userName") || "Doctor";

  const [themeMode, setThemeMode] = useState<ThemeMode>(() => getInitialTheme());

  useEffect(() => {
    applyTheme(themeMode);
    localStorage.setItem(THEME_KEY, themeMode);
  }, [themeMode]);

  const toggleTheme = () => {
    setThemeMode((prev) => (prev === "dark" ? "light" : "dark"));
  };

  const handleLogout = () => {
    clearAuth();
    navigate("/login", { replace: true });
  };

  const handleNavClick = () => {
    if (window.innerWidth < 1024) onToggle();
  };

  const navItems = [
    {
      label: "Overview",
      to: "/app/DoctorDashboard",
      Icon: LayoutDashboardIcon,
    },
    {
      label: "Today's schedule",
      to: "/doctor/appointments",
      Icon: CalendarDaysIcon,
    },
    {
      label: "Cases",
      to: "/doctor/cases",
      Icon: ClipboardListIcon,
    },
    {
      label: "Patients",
      to: "/doctor/patients",
      Icon: UsersIcon,
    },
    {
      label: "Insights",
      to: "/doctor/insights",
      Icon: ActivityIcon,
    },
    { label: "Notifications", to: "/doctor/notifications", Icon: BellIcon },

  ];

  const supportItems = [
    {
      label: "Help & docs",
      to: "/doctor/help",
      Icon: HelpCircleIcon,
    },
  ];

  const SidebarBody: React.FC = () => (
    <div className="flex h-full flex-col bg-slate-950 text-slate-50 border-r border-slate-800">
      {/* HEADER */}
      <div
        className={`flex items-center border-b border-slate-800 gap-2 ${
          isOpen
            ? "justify-between px-3 pt-3 pb-3"
            : "justify-center px-1 py-3"
        }`}
      >
        {isOpen && (
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-2xl bg-slate-900 border border-slate-800 grid place-items-center">
              <StethoscopeIcon size={18} className="text-emerald-300" />
            </div>
            <div className="leading-tight">
              <div className="text-sm font-semibold">Doctor Console</div>
              {/* removed username line here (duplicate) */}
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={onToggle}
          className="inline-flex h-8 w-8 items-center justify-center rounded-full hover:bg-slate-800 text-slate-400"
          aria-label={isOpen ? "Collapse sidebar" : "Expand sidebar"}
        >
          <PanelLeftIcon
            size={18}
            className={isOpen ? "rotate-180 transition-transform" : "transition-transform"}
          />
        </button>
      </div>

      {/* MAIN NAV */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-6">
        <div>
          {isOpen && (
            <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-500 mb-2.5">
              Workspace
            </div>
          )}
          <nav className="space-y-1">
            {navItems.map(({ label, to, Icon }) => {
              const isOverview =
                label === "Overview" &&
                (location.pathname === "/app/DoctorDashboard" ||
                  location.pathname === "/doctor");

              return (
                <NavLink
                  key={label}
                  to={to}
                  className={({ isActive }) =>
                    [
                      navItemBase,
                      isOpen
                        ? "px-3 gap-2.5 justify-start"
                        : "px-0 gap-0 justify-center",
                      isActive || isOverview ? activeStyles : inactiveStyles,
                    ].join(" ")
                  }
                  onClick={handleNavClick}
                >
                  <Icon size={18} className="shrink-0" />
                  {isOpen && <span>{label}</span>}
                </NavLink>
              );
            })}
          </nav>
        </div>

        {/* SUPPORT */}
        <div>
          {isOpen && (
            <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-500 mb-2.5">
              Support
            </div>
          )}
          <nav className="space-y-1">
            {supportItems.map(({ label, to, Icon }) => (
              <NavLink
                key={label}
                to={to}
                className={({ isActive }) =>
                  [
                    navItemBase,
                    isOpen
                      ? "px-3 gap-2.5 justify-start"
                      : "px-0 gap-0 justify-center",
                    isActive ? activeStyles : inactiveStyles,
                    "text-slate-300",
                  ].join(" ")
                }
                onClick={handleNavClick}
              >
                <Icon size={18} className="shrink-0" />
                {isOpen && <span>{label}</span>}
              </NavLink>
            ))}
          </nav>
        </div>
      </div>

      {/* FOOTER: theme + user + logout */}
      <div className="border-t border-slate-800 px-3 py-3 space-y-2">
        {isOpen && (
          <div className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900 px-2 py-1.5">
            <span className="text-[11px] text-slate-400">Appearance</span>
            <div className="inline-flex items-center gap-1 rounded-xl bg-slate-900">
              <button
                type="button"
                onClick={toggleTheme}
                className={`h-7 w-7 rounded-lg grid place-items-center text-slate-300 ${
                  themeMode === "light"
                    ? "bg-slate-100 text-slate-900"
                    : "hover:bg-slate-800"
                }`}
                aria-label="Light theme"
              >
                <SunIcon size={15} />
              </button>
              <button
                type="button"
                onClick={toggleTheme}
                className={`h-7 w-7 rounded-lg grid place-items-center text-slate-300 ${
                  themeMode === "dark"
                    ? "bg-slate-800 text-slate-50"
                    : "hover:bg-slate-800"
                }`}
                aria-label="Dark theme"
              >
                <MoonIcon size={15} />
              </button>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-slate-800 grid place-items-center text-xs font-semibold text-slate-100">
              <UserIcon size={14} />
            </div>
            {isOpen && (
              <div className="leading-tight">
                <p className="text-xs font-medium text-slate-100">
                  {userName}
                </p>
                <p className="text-[11px] text-slate-500">Signed in</p>
              </div>
            )}
          </div>

          {/* logout only when open */}
          {isOpen && (
            <button
              type="button"
              onClick={handleLogout}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-700 px-2.5 py-1 text-[11px] font-medium text-slate-200 hover:bg-slate-800/80 transition"
            >
              <LogOutIcon size={13} />
              <span>Logout</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* DESKTOP rail */}
      <aside
        className={`hidden lg:block h-screen overflow-hidden transition-[width] duration-150 ease-out ${
          isOpen ? "w-64" : "w-16"
        }`}
      >
        <SidebarBody />
      </aside>

      {/* MOBILE drawer */}
      <div
        className={`fixed inset-0 z-40 lg:hidden ${
          isOpen ? "pointer-events-auto" : "pointer-events-none"
        }`}
      >
        <div
          className={`absolute inset-0 bg-black/40 transition-opacity ${
            isOpen ? "opacity-100" : "opacity-0"
          }`}
          onClick={onToggle}
          aria-hidden="true"
        />
        <aside
          className={`absolute inset-y-0 left-0 w-64 max-w-[80%] h-full bg-slate-950 shadow-2xl transform transition-transform duration-200 ${
            isOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <SidebarBody />
        </aside>
      </div>
    </>
  );
};
